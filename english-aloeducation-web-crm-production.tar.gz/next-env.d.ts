/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: This file should not be edited.
// It is automatically maintained by Next.js on `next dev` / `next build`.
