import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { mkdir, writeFile } from "fs/promises";
import { extname, join, basename } from "path";

import { getServerSession } from "@/lib/auth";

const UPLOAD_DIR = "/var/www/english-aloeducation/uploads";

const ALLOWED_MIME = new Set([
  // Audio
  "audio/mpeg",
  "audio/mp3",
  "audio/wav",
  "audio/x-wav",
  "audio/ogg",
  "audio/webm",
  "audio/mp4",
  "audio/aac",
  // Documents
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "text/plain",
  "text/csv",
  // Images
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
]);

const MAX_BYTES = 25 * 1024 * 1024; // 25 MB

/**
 * POST /api/upload
 * Accept a multipart file upload and persist it to
 * `/var/www/english-aloeducation/uploads/<yyyy>/<mm>/<uuid><ext>`.
 *
 * Returns the relative path that can be stored in the DB and later
 * served via the public `/uploads/*` route.
 */
export async function POST(req: NextRequest) {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let formData: FormData;
  try {
    formData = await req.formData();
  } catch {
    return NextResponse.json({ error: "Expected multipart/form-data" }, { status: 400 });
  }

  const file = formData.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Missing 'file' field" }, { status: 400 });
  }

  if (file.size === 0) {
    return NextResponse.json({ error: "File is empty" }, { status: 422 });
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json(
      { error: `File exceeds the ${MAX_BYTES / 1024 / 1024} MB limit` },
      { status: 413 },
    );
  }
  if (file.type && !ALLOWED_MIME.has(file.type)) {
    return NextResponse.json({ error: `Unsupported file type: ${file.type}` }, { status: 415 });
  }

  // Build the destination path: <UPLOAD_DIR>/<yyyy>/<mm>/<uuid><ext>
  const now = new Date();
  const yyyy = now.getUTCFullYear().toString();
  const mm = String(now.getUTCMonth() + 1).padStart(2, "0");
  const ext = extname(file.name) || defaultExtensionFor(file.type);
  const safeBase = `${randomUUID()}${ext}`;
  const relDir = join(yyyy, mm);
  const absDir = join(UPLOAD_DIR, relDir);

  try {
    await mkdir(absDir, { recursive: true });
    const buffer = Buffer.from(await file.arrayBuffer());
    await writeFile(join(absDir, safeBase), buffer);
  } catch (err) {
    console.error("[POST /api/upload] write failed:", err);
    return NextResponse.json({ error: "Failed to persist upload" }, { status: 500 });
  }

  // Relative path stored in the DB — served by the public static folder
  // or a dedicated streaming route.
  const relativePath = `${relDir}/${safeBase}`;
  const publicUrl = `/uploads/${relativePath}`;

  return NextResponse.json(
    {
      path: relativePath,
      url: publicUrl,
      filename: basename(safeBase),
      originalName: file.name,
      mimeType: file.type || "application/octet-stream",
      size: file.size,
    },
    { status: 201 },
  );
}

/** Fallback extension when the client did not supply one. */
function defaultExtensionFor(mime: string | undefined): string {
  if (!mime) return ".bin";
  const map: Record<string, string> = {
    "audio/mpeg": ".mp3",
    "audio/mp3": ".mp3",
    "audio/wav": ".wav",
    "audio/x-wav": ".wav",
    "audio/ogg": ".ogg",
    "audio/webm": ".webm",
    "audio/mp4": ".m4a",
    "audio/aac": ".aac",
    "application/pdf": ".pdf",
    "application/msword": ".doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.ms-powerpoint": ".ppt",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
    "application/vnd.ms-excel": ".xls",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "text/plain": ".txt",
    "text/csv": ".csv",
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/gif": ".gif",
  };
  return map[mime] ?? ".bin";
}
