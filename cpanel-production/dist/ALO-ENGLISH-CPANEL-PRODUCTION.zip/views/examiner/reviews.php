<?php
/** views/examiner/reviews.php — Reviews. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Reviews';
require __DIR__ . '/../layouts/header.php';

$rows = isset($rows) && is_array($rows) ? $rows : [["id"=>"W-4815","student"=>"Tanvir Ahmed","exam"=>"IELTS-A","submitted"=>"2025-01-14","score"=>"6.5","status"=>"submitted"]];
?>
<section class="container alo-section"><header class="alo-section__head"><h1>Your reviews</h1></header>
<div class="alo-table-wrap"><table class="alo-table"><thead><tr><th>Submission</th><th>Student</th><th>Exam</th><th>Submitted</th><th>Score</th><th>Status</th></tr></thead><tbody>
<?php foreach ($rows as $row): $cls=$row["status"]==="submitted"?"success":"warn"; ?>
<tr><td class="alo-mono"><?= $e($row["id"]) ?></td><td><?= $e($row["student"]) ?></td><td><span class="alo-badge alo-badge--info"><?= $e($row["exam"]) ?></span></td><td class="alo-mono"><?= $e($row["submitted"]) ?></td><td><?= $e($row["score"]) ?></td><td><span class="alo-badge alo-badge--<?= $cls ?>"><?= $e($row["status"]) ?></span></td></tr>
<?php endforeach; ?>
</tbody></table></div>
<section class="card"><header class="alo-card__head"><h2>Submit a review</h2></header><form class="alo-form" method="post"><input type="hidden" name="csrf_token" value="<?= $e(isset($csrf_token) ? $csrf_token : "") ?>"><div class="form-row"><label class="form-label">Submission ID</label><input class="form-input" type="text" name="submission_id" required></div><div class="form-row"><label class="form-label">Score</label><input class="form-input" type="text" name="score" required></div><div class="form-row"><label class="form-label">Feedback</label><textarea class="form-input" name="feedback" rows="4"></textarea></div><div class="form-row"><button class="btn btn-primary" type="submit">Submit review</button></div></form></section><div class="alo-disclaimer-banner" role="note"><strong>Practice only.</strong> All content is original, exam-aligned practice material — not official exam content.</div></section>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
