<?php
/** views/ambassador/create-referral.php — Create referral. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Create referral';
require __DIR__ . '/../layouts/header.php';

$code = isset($referral_code) ? $referral_code : "AMB-2025-0042";
$link = "https://english.aloeducation.com/register?ref=" . $code;
?>
<section class="container alo-section alo-section--narrow"><header class="alo-section__head"><h1>Create a referral</h1></header>
<form class="card alo-form" method="post"><input type="hidden" name="csrf_token" value="<?= $e(isset($csrf_token) ? $csrf_token : "") ?>">
<div class="form-row"><label class="form-label">Student name</label><input class="form-input" type="text" name="name" required></div>
<div class="form-row"><label class="form-label">Student email</label><input class="form-input" type="email" name="email" required></div>
<div class="form-row"><button class="btn btn-primary" type="submit">Send invitation</button></div></form>
<section class="card"><header class="alo-card__head"><h2>Your shareable link</h2></header><p>Code: <code class="alo-mono"><?= $e($code) ?></code></p><p><input class="form-input alo-mono" type="text" readonly value="<?= $e($link) ?>" onclick="this.select()"></p></section></section>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
