<?php
/** views/student/study-plan.php — Study plan. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Study plan';
require __DIR__ . '/../layouts/header.php';

$weaknesses = isset($weaknesses) && is_array($weaknesses) ? $weaknesses : [["area"=>"Writing — coherence","score"=>"6.0","priority"=>"High","recommended"=>"IELTS-A-SET-009"],["area"=>"Speaking — lexical","score"=>"6.5","priority"=>"Medium","recommended"=>"Vocabulary drills"]];
?>
<section class="container alo-section"><header class="alo-section__head"><h1>Your study plan</h1></header>
<div class="alo-table-wrap"><table class="alo-table"><thead><tr><th>Area</th><th>Last score</th><th>Priority</th><th>Recommended</th></tr></thead><tbody>
<?php foreach ($weaknesses as $w): $cls=["High"=>"danger","Medium"=>"warn","Low"=>"info"][$w["priority"]]??"info"; ?>
<tr><td><?= $e($w["area"]) ?></td><td><?= $e($w["score"]) ?></td><td><span class="alo-badge alo-badge--<?= $cls ?>"><?= $e($w["priority"]) ?></span></td><td><?= $e($w["recommended"]) ?></td></tr>
<?php endforeach; ?>
</tbody></table></div><p><a class="btn btn-primary" href="/student/tests">Browse practice tests →</a></p></section>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
