<?php
/** views/student/start-test.php — Start practice test. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Start practice test';
require __DIR__ . '/../layouts/header.php';

$set = isset($set) && is_array($set) ? $set : ["id"=>"IELTS-A-SET-007","exam"=>"IELTS-A","title"=>"IELTS Academic Mock 7","questions"=>60,"duration_min"=>165];
?>
<section class="container alo-section alo-section--narrow">
    <header class="alo-section__head"><h1><?= $e($set["title"]) ?></h1><span class="alo-badge alo-badge--info"><?= $e($set["exam"]) ?></span></header>
    <div class="card">
        <h2>Before you begin</h2>
        <ul class="alo-list">
            <li><?= $e((string)$set["questions"]) ?> questions</li>
            <li>Time limit: <strong><?= $e((string)$set["duration_min"]) ?> minutes</strong></li>
            <li>On submit, your Smart Score Report is generated automatically by the ALO Evaluation System.</li>
        </ul>
        <form method="post" action="/mock-test/start">
            <input type="hidden" name="csrf_token" value="<?= $e(isset($csrf_token) ? $csrf_token : "") ?>">
            <input type="hidden" name="set_id" value="<?= $e($set["id"]) ?>">
            <label class="form-label"><input type="checkbox" name="consent_proctor" value="1" required> I consent to the exam-disclaimer terms.</label>
            <div class="form-row"><button class="btn btn-primary" type="submit">Begin practice test →</button></div>
        </form>
    </div>
    <div class="alo-disclaimer-banner" role="note"><strong>Practice only.</strong> All content is original, exam-aligned practice material — not official exam content.</div>
</section>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
