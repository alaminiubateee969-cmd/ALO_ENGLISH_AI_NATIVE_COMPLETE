<?php
/** views/student/results.php — Your results. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Your results';
require __DIR__ . '/../layouts/header.php';

$results = isset($results) && is_array($results) ? $results : [
    ["id"=>"ATT-001","exam"=>"IELTS-A","date"=>"2025-01-15","score"=>"7.0","status"=>"auto_generated"],
    ["id"=>"ATT-002","exam"=>"PTE-A","date"=>"2025-01-12","score"=>"73","status"=>"auto_generated"],
];
?>
<section class="container alo-section">
    <header class="alo-section__head"><h1>Your results</h1></header>
    <div class="alo-table-wrap"><table class="alo-table"><thead><tr><th>Attempt</th><th>Exam</th><th>Date</th><th>Score</th><th>Status</th><th></th></tr></thead><tbody>
        <?php foreach ($results as $r): ?>
            <tr><td class="alo-mono"><?= $e($r["id"]) ?></td><td><span class="alo-badge alo-badge--info"><?= $e($r["exam"]) ?></span></td><td class="alo-mono"><?= $e($r["date"]) ?></td><td><strong><?= $e($r["score"]) ?></strong></td><td><span class="alo-badge alo-badge--success"><?= $e(str_replace("_"," ",$r["status"])) ?></span></td><td><a class="btn btn-link" href="/student/results/<?= $e($r["id"]) ?>">View →</a></td></tr>
        <?php endforeach; ?>
    </tbody></table></div>
    <div class="alo-disclaimer-banner" role="note"><strong>Practice only.</strong> All content is original, exam-aligned practice material — not official exam content.</div>
</section>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
