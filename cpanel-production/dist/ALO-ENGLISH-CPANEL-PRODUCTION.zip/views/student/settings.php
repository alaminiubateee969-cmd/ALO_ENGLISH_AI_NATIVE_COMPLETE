<?php
/** views/student/settings.php — Account settings. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Account settings';
require __DIR__ . '/../layouts/header.php';

$user = isset($user) && is_array($user) ? $user : ["name"=>"Student","email"=>"student@example.com","locale"=>"en","timezone"=>"Asia/Kolkata"];
?>
<section class="container alo-section alo-section--narrow"><header class="alo-section__head"><h1>Account settings</h1></header>
<form class="card alo-form" method="post"><input type="hidden" name="csrf_token" value="<?= $e(isset($csrf_token) ? $csrf_token : "") ?>">
<div class="form-row"><label class="form-label">Full name</label><input class="form-input" type="text" name="name" value="<?= $e($user["name"]) ?>" required></div>
<div class="form-row"><label class="form-label">Email</label><input class="form-input" type="email" name="email" value="<?= $e($user["email"]) ?>" required></div>
<div class="form-row"><button class="btn btn-primary" type="submit">Save changes</button></div></form></section>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
