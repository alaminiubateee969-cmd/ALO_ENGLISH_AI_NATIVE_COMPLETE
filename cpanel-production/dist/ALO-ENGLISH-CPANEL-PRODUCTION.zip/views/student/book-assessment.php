<?php
/** views/student/book-assessment.php — Book an assessment. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Book an assessment';
require __DIR__ . '/../layouts/header.php';

?>
<section class="container alo-section alo-section--narrow"><header class="alo-section__head"><h1>Book an assessment call</h1></header>
<form class="card alo-form" method="post"><input type="hidden" name="csrf_token" value="<?= $e(isset($csrf_token) ? $csrf_token : "") ?>">
<div class="form-row"><label class="form-label">Target exam</label><select class="form-input" name="exam"><option>IELTS Academic</option><option>PTE Academic</option><option>TOEFL iBT</option></select></div>
<div class="form-row"><label class="form-label">Preferred date</label><input class="form-input" type="date" name="date" required></div>
<div class="form-row"><label class="form-label">Preferred time</label><input class="form-input" type="time" name="time" required></div>
<div class="form-row"><button class="btn btn-primary" type="submit">Request booking</button></div></form></section>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
