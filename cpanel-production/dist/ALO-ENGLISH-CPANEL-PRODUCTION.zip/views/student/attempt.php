<?php
/** views/student/attempt.php — Practice test — in progress. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Practice test — in progress';
require __DIR__ . '/../layouts/header.php';

$attempt = isset($attempt) && is_array($attempt) ? $attempt : ["id"=>"ATT-001","set_id"=>"SET-001","exam_code"=>"IELTS-A","duration_sec"=>9900];
$questions = isset($questions) && is_array($questions) ? $questions : [
    ["id"=>"Q1","index"=>1,"type"=>"multiple_choice","section"=>"Listening","prompt"=>"The library closes at ____ on weekdays.","options"=>["5:00 PM","6:30 PM","8:00 PM","9:30 PM"]],
    ["id"=>"Q2","index"=>2,"type"=>"multiple_choice","section"=>"Listening","prompt"=>"What is the main purpose of the announcement?","options"=>["To advertise","To inform","To recruit","To announce"]],
];
$total = count($questions);
?>
<section class="container alo-section alo-mocktest" data-attempt="<?= $e($attempt["id"]) ?>">
    <header class="alo-section__head">
        <div><h1><?= $e($attempt["exam_code"]) ?> — Practice Test</h1><p class="alo-muted">Attempt: <?= $e($attempt["id"]) ?></p></div>
        <div class="alo-mocktest__timer" id="timer" data-duration="<?= $e((string)$attempt["duration_sec"]) ?>"><span class="alo-mono" id="timer-display">--:--:--</span></div>
    </header>
    <div class="alo-grid alo-grid--mocktest">
        <aside class="card alo-palette">
            <header class="alo-card__head"><h2>Questions</h2></header>
            <div class="alo-palette__grid" id="palette">
                <?php for ($i = 1; $i <= $total; $i++): ?>
                    <button type="button" class="alo-palette__btn <?= $i === 1 ? "is-current" : "" ?>" data-q="<?= $i ?>"><?= $i ?></button>
                <?php endfor; ?>
            </div>
            <form method="post" action="/mock-test/submit" id="submit-form">
                <input type="hidden" name="csrf_token" value="<?= $e(isset($csrf_token) ? $csrf_token : "") ?>">
                <button class="btn btn-danger" type="submit" onclick="return confirm(\"Submit test?\")">Submit test</button>
            </form>
        </aside>
        <section class="card alo-question" id="question-area">
            <?php foreach ($questions as $qi => $q): ?>
                <article class="alo-question__item" data-index="<?= $e((string)$q["index"]) ?>" <?= $qi > 0 ? "hidden" : "" ?>>
                    <header class="alo-card__head"><span class="alo-badge alo-badge--info"><?= $e($q["section"]) ?></span><h2>Question <?= $e((string)$q["index"]) ?> of <?= $e((string)$total) ?></h2></header>
                    <p class="alo-question__prompt"><?= $e($q["prompt"]) ?></p>
                    <ul class="alo-question__options">
                        <?php foreach ($q["options"] as $oi => $opt): ?>
                            <li><label class="alo-option"><input type="radio" name="answer_<?= $e($q["id"]) ?>" value="<?= $e((string)($oi + 1)) ?>"><span class="alo-option__marker"><?= $e(chr(65 + $oi)) ?></span><span><?= $e($opt) ?></span></label></li>
                        <?php endforeach; ?>
                    </ul>
                </article>
            <?php endforeach; ?>
            <div class="alo-question__nav"><button class="btn btn-secondary" id="prev-btn">← Previous</button><button class="btn btn-secondary" id="next-btn">Next →</button></div>
        </section>
    </div>
    <div class="alo-disclaimer-banner" role="note"><strong>Practice only.</strong> All content is original, exam-aligned practice material — not official exam content.</div>
</section>
<script>
(function(){var d=parseInt(document.getElementById("timer").dataset.duration,10)||0;var end=Date.now()+d*1000;function p(n){return n<10?"0"+n:""+n}function t(){var l=Math.max(0,Math.floor((end-Date.now())/1000));document.getElementById("timer-display").textContent=p(Math.floor(l/3600))+":"+p(Math.floor((l%3600)/60))+":"+p(l%60);if(l<=0)document.getElementById("submit-form").submit()}setInterval(t,1000);t();var items=document.querySelectorAll(".alo-question__item");var btns=document.querySelectorAll(".alo-palette__btn[data-q]");var cur=0;function show(i){items.forEach(function(el,idx){el.hidden=idx!==i});btns.forEach(function(b,bi){b.classList.toggle("is-current",bi===i)})}show(0);document.getElementById("prev-btn").onclick=function(){if(cur>0){cur--;show(cur)}};document.getElementById("next-btn").onclick=function(){if(cur<items.length-1){cur++;show(cur)}};btns.forEach(function(b,bi){b.onclick=function(){cur=bi;show(cur)}})})();
</script>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
