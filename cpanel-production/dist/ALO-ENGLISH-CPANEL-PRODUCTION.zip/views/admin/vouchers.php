<?php
/** views/admin/vouchers.php — Vouchers. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Vouchers';
require __DIR__ . '/../layouts/header.php';

$vouchers = isset($vouchers) && is_array($vouchers) ? $vouchers : [["code"=>"ALO-WELCOME-2025","type"=>"Free attempt","discount"=>"1 free","issued"=>"2025-01-01","expiry"=>"2025-03-31","used"=>"142 / 500","status"=>"active"]];
?>
<section class="container alo-section"><header class="alo-section__head"><h1>Vouchers</h1><p><a class="btn btn-primary" href="#">+ Issue voucher</a></p></header>
<div class="alo-table-wrap"><table class="alo-table"><thead><tr><th>Code</th><th>Type</th><th>Discount</th><th>Issued</th><th>Expiry</th><th>Used</th><th>Status</th></tr></thead><tbody>
<?php foreach ($vouchers as $v): $cls=$v["status"]==="active"?"success":"danger"; ?>
<tr><td class="alo-mono"><?= $e($v["code"]) ?></td><td><?= $e($v["type"]) ?></td><td><?= $e($v["discount"]) ?></td><td class="alo-mono"><?= $e($v["issued"]) ?></td><td class="alo-mono"><?= $e($v["expiry"]) ?></td><td><?= $e($v["used"]) ?></td><td><span class="alo-badge alo-badge--<?= $cls ?>"><?= $e($v["status"]) ?></span></td></tr>
<?php endforeach; ?>
</tbody></table></div></section>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
