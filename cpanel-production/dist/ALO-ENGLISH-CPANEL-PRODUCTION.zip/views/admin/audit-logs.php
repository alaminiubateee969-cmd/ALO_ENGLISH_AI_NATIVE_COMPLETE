<?php
/** views/admin/audit-logs.php — Audit logs. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Audit logs';
require __DIR__ . '/../layouts/header.php';

$logs = isset($logs) && is_array($logs) ? $logs : [["time"=>"2025-01-15 14:02","actor"=>"admin@alo","action"=>"QUESTION_PUBLISH","target"=>"Q-2003","ip"=>"103.231.239.79"],["time"=>"2025-01-15 13:48","actor"=>"examiner@alo","action"=>"REVIEW_SUBMIT","target"=>"W-4815","ip"=>"103.231.239.79"]];
?>
<section class="container alo-section"><header class="alo-section__head"><h1>Audit logs</h1><input class="form-input" type="search" placeholder="Filter…"></header>
<div class="alo-table-wrap"><table class="alo-table alo-table--compact"><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Target</th><th>IP</th></tr></thead><tbody>
<?php foreach ($logs as $l): $cls=str_contains($l["action"],"FAILED")?"danger":(str_contains($l["action"],"SUCCESS")?"success":"info"); ?>
<tr><td class="alo-mono"><?= $e($l["time"]) ?></td><td><?= $e($l["actor"]) ?></td><td><span class="alo-badge alo-badge--<?= $cls ?>"><?= $e($l["action"]) ?></span></td><td class="alo-mono"><?= $e($l["target"]) ?></td><td class="alo-mono"><?= $e($l["ip"]) ?></td></tr>
<?php endforeach; ?>
</tbody></table></div><p class="alo-muted">Audit logs are immutable and retained for 365 days.</p></section>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
