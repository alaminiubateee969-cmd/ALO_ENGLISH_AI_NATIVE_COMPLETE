<?php
/** views/admin/exam-types.php — Exam types. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Exam types';
require __DIR__ . '/../layouts/header.php';

$exams = isset($exams) && is_array($exams) ? $exams : [["code"=>"IELTS-A","name"=>"IELTS Academic","category"=>"English Proficiency","sets"=>24,"status"=>"published"],["code"=>"PTE-A","name"=>"PTE Academic","category"=>"English Proficiency","sets"=>18,"status"=>"published"],["code"=>"TOEFL-iBT","name"=>"TOEFL iBT","category"=>"English Proficiency","sets"=>15,"status"=>"published"]];
?>
<section class="container alo-section"><header class="alo-section__head"><h1>Exam types (32)</h1></header>
<div class="alo-table-wrap"><table class="alo-table"><thead><tr><th>Code</th><th>Name</th><th>Category</th><th>Practice sets</th><th>Status</th></tr></thead><tbody>
<?php foreach ($exams as $ex): ?><tr><td class="alo-mono"><?= $e($ex["code"]) ?></td><td><?= $e($ex["name"]) ?></td><td><?= $e($ex["category"]) ?></td><td><?= $e((string)$ex["sets"]) ?></td><td><span class="alo-badge alo-badge--success"><?= $e($ex["status"]) ?></span></td></tr><?php endforeach; ?>
</tbody></table></div></section>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
