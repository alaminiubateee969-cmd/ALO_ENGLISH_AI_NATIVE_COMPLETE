<?php
/** views/admin/modules.php — Exam modules. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Exam modules';
require __DIR__ . '/../layouts/header.php';

$modules = isset($modules) && is_array($modules) ? $modules : [["exam"=>"IELTS-A","module"=>"Listening","questions"=>40,"duration_min"=>30,"type"=>"audio"],["exam"=>"IELTS-A","module"=>"Reading","questions"=>40,"duration_min"=>60,"type"=>"text"]];
?>
<section class="container alo-section"><header class="alo-section__head"><h1>Exam modules</h1></header>
<div class="alo-table-wrap"><table class="alo-table"><thead><tr><th>Exam</th><th>Module</th><th>Questions</th><th>Duration</th><th>Type</th></tr></thead><tbody>
<?php foreach ($modules as $m): ?><tr><td><span class="alo-badge alo-badge--info"><?= $e($m["exam"]) ?></span></td><td><?= $e($m["module"]) ?></td><td><?= $e((string)$m["questions"]) ?></td><td><?= $e((string)$m["duration_min"]) ?> min</td><td class="alo-mono"><?= $e($m["type"]) ?></td></tr><?php endforeach; ?>
</tbody></table></div></section>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
