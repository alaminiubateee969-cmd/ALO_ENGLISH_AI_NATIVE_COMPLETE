<?php
/** views/admin/agent-logs.php — Agent logs. PHP 8.2+. */
<?php if (!isset($e) || !is_callable($e)) { $e = static fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8"); }
$title = 'Agent logs';
require __DIR__ . '/../layouts/header.php';

$logs = [["time"=>"2025-01-15 14:02:11","agent"=>"AGENT-QGEN-01","level"=>"INFO","message"=>"Generated 20 draft questions for IELTS-A"],["time"=>"2025-01-15 13:45:09","agent"=>"AGENT-WRITE-01","level"=>"INFO","message"=>"Evaluated ATT-482 writing (confidence 0.88)"],["time"=>"2025-01-15 13:30:00","agent"=>"AGENT-CRM-01","level"=>"WARN","message"=>"CRM sync timeout for SYNC-5008, will retry in 4h"],["time"=>"2025-01-15 11:08:22","agent"=>"AGENT-WRITE-01","level"=>"WARN","message"=>"Low confidence (0.41) for ATT-470, review recommended"]];
?>
<section class="container alo-section"><header class="alo-section__head"><h1>Agent operational logs</h1><input class="form-input" type="search" placeholder="Filter…"></header>
<div class="alo-table-wrap"><table class="alo-table alo-table--compact"><thead><tr><th>Time</th><th>Agent</th><th>Level</th><th>Message</th></tr></thead><tbody>
<?php foreach ($logs as $l): $cls=["INFO"=>"info","WARN"=>"warn","ERROR"=>"danger"][$l["level"]]??"info"; ?>
<tr><td class="alo-mono"><?= $e($l["time"]) ?></td><td class="alo-mono"><?= $e($l["agent"]) ?></td><td><span class="alo-badge alo-badge--<?= $cls ?>"><?= $e($l["level"]) ?></span></td><td><?= $e($l["message"]) ?></td></tr>
<?php endforeach; ?>
</tbody></table></div><p class="alo-muted">Logs are append-only and retained for 90 days.</p></section>
<?php require __DIR__ . '/../layouts/footer.php'; ?>
